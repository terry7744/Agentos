-- =========================================================
-- AgentOS — schéma D1 (isolation multi-tenant stricte par org_id)
-- =========================================================

CREATE TABLE IF NOT EXISTS organizations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  plan TEXT NOT NULL DEFAULT 'free', -- free | pro | business | enterprise
  created_at INTEGER NOT NULL DEFAULT (unixepoch())
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  email TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'member', -- owner | admin | developer | manager | member | viewer
  created_at INTEGER NOT NULL DEFAULT (unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_users_org ON users(org_id);

CREATE TABLE IF NOT EXISTS agents (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  name TEXT NOT NULL,
  system_instructions TEXT NOT NULL,
  model TEXT NOT NULL DEFAULT '@cf/meta/llama-3.1-70b-instruct',
  autonomy_level INTEGER NOT NULL DEFAULT 1, -- 0..5
  max_steps INTEGER NOT NULL DEFAULT 12,
  max_tool_calls INTEGER NOT NULL DEFAULT 20,
  max_tokens_budget INTEGER NOT NULL DEFAULT 50000,
  timeout_ms INTEGER NOT NULL DEFAULT 60000,
  tools_json TEXT NOT NULL DEFAULT '[]',      -- liste des tool names autorisés
  guardrails_json TEXT NOT NULL DEFAULT '{}', -- config des guardrails
  created_at INTEGER NOT NULL DEFAULT (unixepoch()),
  updated_at INTEGER NOT NULL DEFAULT (unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_agents_org ON agents(org_id);

CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  agent_id TEXT NOT NULL REFERENCES agents(id),
  user_id TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- pending | running | waiting_approval | completed | failed | stopped
  input TEXT NOT NULL,
  output TEXT,
  steps_used INTEGER NOT NULL DEFAULT 0,
  tokens_used INTEGER NOT NULL DEFAULT 0,
  tool_calls_used INTEGER NOT NULL DEFAULT 0,
  error TEXT,
  started_at INTEGER NOT NULL DEFAULT (unixepoch()),
  finished_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_runs_org ON runs(org_id);
CREATE INDEX IF NOT EXISTS idx_runs_agent ON runs(agent_id);

CREATE TABLE IF NOT EXISTS run_steps (
  id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL REFERENCES runs(id),
  step_number INTEGER NOT NULL,
  type TEXT NOT NULL, -- reasoning | tool_call | tool_result | approval_requested | final_answer
  content TEXT NOT NULL,
  created_at INTEGER NOT NULL DEFAULT (unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_steps_run ON run_steps(run_id);

CREATE TABLE IF NOT EXISTS tool_approvals (
  id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL REFERENCES runs(id),
  org_id TEXT NOT NULL REFERENCES organizations(id),
  tool_name TEXT NOT NULL,
  risk_level TEXT NOT NULL, -- LOW | MEDIUM | HIGH | CRITICAL
  input_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', -- pending | approved | rejected
  decided_by TEXT,
  decided_at INTEGER,
  created_at INTEGER NOT NULL DEFAULT (unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_approvals_org ON tool_approvals(org_id);
CREATE INDEX IF NOT EXISTS idx_approvals_status ON tool_approvals(status);

CREATE TABLE IF NOT EXISTS memory_items (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  agent_id TEXT NOT NULL REFERENCES agents(id),
  scope TEXT NOT NULL, -- short_term | long_term | episodic
  key TEXT,
  value TEXT NOT NULL,
  created_at INTEGER NOT NULL DEFAULT (unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_memory_agent ON memory_items(agent_id);

CREATE TABLE IF NOT EXISTS knowledge_documents (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  agent_id TEXT,
  title TEXT NOT NULL,
  source_type TEXT NOT NULL, -- pdf | docx | txt | url | md | csv
  r2_key TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- pending | indexed | failed
  created_at INTEGER NOT NULL DEFAULT (unixepoch())
);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  actor_id TEXT,
  action TEXT NOT NULL,
  target TEXT,
  metadata_json TEXT,
  created_at INTEGER NOT NULL DEFAULT (unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_audit_org ON audit_log(org_id);

CREATE TABLE IF NOT EXISTS api_keys (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  name TEXT NOT NULL,
  key_hash TEXT NOT NULL,
  scopes_json TEXT NOT NULL DEFAULT '[]',
  revoked INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL DEFAULT (unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_apikeys_org ON api_keys(org_id);

/**
 * Seed script — à exécuter une fois la base D1 migrée.
 *
 * Usage :
 *   npx wrangler d1 execute agentos_db --file=./src/db/seed.sql
 *
 * Ce script crée :
 *  - une organisation "Halo IA" (Samy Miout)
 *  - un utilisateur owner
 *  - un premier agent de test avec accès au tool knowledge_search (LOW risk uniquement)
 *  - une clé API en clair affichée UNE SEULE FOIS ci-dessous (à copier avant migration)
 *
 * IMPORTANT SÉCURITÉ :
 * La clé API en clair est : agos_live_7f3c9a1e4b6d2f8095c3a7e1b4d6f209
 * Elle n'est jamais stockée en clair en base — seul son hash SHA-256 l'est.
 * Régénère une clé à toi avant tout usage réel (voir generate-api-key.ts).
 */

INSERT INTO organizations (id, name, plan) VALUES
  ('org_halo_ia', 'Halo IA', 'free');

INSERT INTO users (id, org_id, email, role) VALUES
  ('user_samy', 'org_halo_ia', 'samy@halo-ia.example', 'owner');

INSERT INTO agents (
  id, org_id, name, system_instructions, model,
  autonomy_level, max_steps, max_tool_calls, max_tokens_budget, timeout_ms,
  tools_json, guardrails_json
) VALUES (
  'agent_demo',
  'org_halo_ia',
  'Agent Démo',
  'Tu es un assistant utile pour Halo IA. Réponds de façon concise et précise. Utilise knowledge_search si tu as besoin d''informations internes.',
  '@cf/meta/llama-3.1-70b-instruct',
  1,
  8,
  10,
  20000,
  30000,
  '["knowledge_search"]',
  '{"requireApprovalAbove":"HIGH"}'
);

-- Hash SHA-256 de "agos_live_7f3c9a1e4b6d2f8095c3a7e1b4d6f209"
-- (recalcule le tien avec generate-api-key.ts, ne réutilise jamais celui-ci en prod)
INSERT INTO api_keys (id, org_id, name, key_hash, scopes_json) VALUES (
  'key_demo',
  'org_halo_ia',
  'Clé de démo locale',
  'REPLACE_WITH_SHA256_OF_YOUR_OWN_KEY',
  '["runs:read","runs:write","approvals:write"]'
);

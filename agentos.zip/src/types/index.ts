export type RiskLevel = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export interface Env {
  DB: D1Database;
  VECTORIZE: VectorizeIndex;
  FILES: R2Bucket;
  AI: Ai;
  AGENT_SESSION: DurableObjectNamespace;
  RUN_QUEUE: Queue;
  ENVIRONMENT: string;
  MAX_STEPS_DEFAULT: string;
  MAX_TOOL_CALLS_DEFAULT: string;
}

export interface AgentConfig {
  id: string;
  orgId: string;
  name: string;
  systemInstructions: string;
  model: string;
  autonomyLevel: 0 | 1 | 2 | 3 | 4 | 5;
  maxSteps: number;
  maxToolCalls: number;
  maxTokensBudget: number;
  timeoutMs: number;
  allowedTools: string[];
  guardrails: GuardrailsConfig;
}

export interface GuardrailsConfig {
  blockPromptInjectionPatterns?: boolean;
  maxOutputChars?: number;
  forbiddenActions?: string[];
  requireApprovalAbove?: RiskLevel; // ex: "HIGH" -> HIGH et CRITICAL nécessitent approbation
}

export interface ToolDefinition<TInput = any, TOutput = any> {
  name: string;
  description: string;
  riskLevel: RiskLevel;
  inputSchema: import("zod").ZodType<TInput>;
  timeoutMs: number;
  retryPolicy: { maxRetries: number; backoffMs: number };
  execute: (input: TInput, ctx: ToolExecutionContext) => Promise<TOutput>;
}

export interface ToolExecutionContext {
  env: Env;
  orgId: string;
  agentId: string;
  runId: string;
}

export type RunStatus =
  | "pending"
  | "running"
  | "waiting_approval"
  | "completed"
  | "failed"
  | "stopped";

export interface RunStepEvent {
  type:
    | "reasoning"
    | "tool_call"
    | "tool_result"
    | "approval_requested"
    | "final_answer"
    | "error";
  content: string;
  toolName?: string;
  riskLevel?: RiskLevel;
}

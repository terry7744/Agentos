import type { AgentConfig, Env, RunStepEvent } from "../types";
import { ToolEngine } from "../tools/tool-engine";
import { builtinTools } from "../tools/builtin-tools";
import { AgentRuntime } from "../runtime/agent-runtime";

function buildToolEngine(): ToolEngine {
  const engine = new ToolEngine();
  for (const tool of builtinTools) engine.register(tool);
  return engine;
}

async function loadAgent(
  env: Env,
  orgId: string,
  agentId: string,
): Promise<AgentConfig | null> {
  const row = await env.DB.prepare(
    `SELECT * FROM agents WHERE id = ? AND org_id = ?`,
  )
    .bind(agentId, orgId)
    .first();

  if (!row) return null;

  return {
    id: row.id as string,
    orgId: row.org_id as string,
    name: row.name as string,
    systemInstructions: row.system_instructions as string,
    model: row.model as string,
    autonomyLevel: row.autonomy_level as any,
    maxSteps: row.max_steps as number,
    maxToolCalls: row.max_tool_calls as number,
    maxTokensBudget: row.max_tokens_budget as number,
    timeoutMs: row.timeout_ms as number,
    allowedTools: JSON.parse(row.tools_json as string),
    guardrails: JSON.parse(row.guardrails_json as string),
  };
}

/**
 * POST /api/v1/agents/:agentId/runs
 * Lance un run. Authentification par API key déjà résolue en amont
 * (voir index.ts) -> orgId est garanti fiable ici.
 */
export async function handleCreateRun(
  request: Request,
  env: Env,
  orgId: string,
  agentId: string,
): Promise<Response> {
  const body = await request.json<{ input: string }>().catch(() => null);
  if (!body?.input) {
    return Response.json({ error: "champ 'input' requis" }, { status: 400 });
  }

  const agent = await loadAgent(env, orgId, agentId);
  if (!agent) {
    return Response.json({ error: "agent introuvable" }, { status: 404 });
  }

  const runId = crypto.randomUUID();
  await env.DB.prepare(
    `INSERT INTO runs (id, org_id, agent_id, status, input) VALUES (?, ?, ?, 'running', ?)`,
  )
    .bind(runId, orgId, agentId, body.input)
    .run();

  const toolEngine = buildToolEngine();
  let stepNumber = 0;

  const onStep = async (event: RunStepEvent) => {
    stepNumber++;
    await env.DB.prepare(
      `INSERT INTO run_steps (id, run_id, step_number, type, content) VALUES (?, ?, ?, ?, ?)`,
    )
      .bind(crypto.randomUUID(), runId, stepNumber, event.type, event.content)
      .run();
  };

  const runtime = new AgentRuntime(env, toolEngine, onStep);
  const result = await runtime.run(agent, runId, body.input);

  await env.DB.prepare(
    `UPDATE runs
     SET status = ?, output = ?, error = ?, steps_used = ?, tool_calls_used = ?,
         tokens_used = ?, finished_at = unixepoch()
     WHERE id = ?`,
  )
    .bind(
      result.status,
      result.output ?? null,
      result.error ?? null,
      result.stepsUsed,
      result.toolCallsUsed,
      result.tokensUsed,
      runId,
    )
    .run();

  return Response.json({ runId, ...result });
}

/** GET /api/v1/runs/:runId */
export async function handleGetRun(
  env: Env,
  orgId: string,
  runId: string,
): Promise<Response> {
  const run = await env.DB.prepare(
    `SELECT * FROM runs WHERE id = ? AND org_id = ?`,
  )
    .bind(runId, orgId)
    .first();

  if (!run) return Response.json({ error: "run introuvable" }, { status: 404 });

  const steps = await env.DB.prepare(
    `SELECT type, content, step_number, created_at FROM run_steps WHERE run_id = ? ORDER BY step_number ASC`,
  )
    .bind(runId)
    .all();

  return Response.json({ run, steps: steps.results });
}

/**
 * POST /api/v1/approvals/:approvalId/decision
 * Body: { decision: "approved" | "rejected", decidedBy: string }
 * C'est le SEUL chemin par lequel un tool HIGH/CRITICAL peut s'exécuter.
 */
export async function handleApprovalDecision(
  request: Request,
  env: Env,
  orgId: string,
  approvalId: string,
): Promise<Response> {
  const body = await request
    .json<{ decision: "approved" | "rejected"; decidedBy: string }>()
    .catch(() => null);

  if (!body || !["approved", "rejected"].includes(body.decision)) {
    return Response.json({ error: "decision invalide" }, { status: 400 });
  }

  const approval = await env.DB.prepare(
    `SELECT * FROM tool_approvals WHERE id = ? AND org_id = ?`,
  )
    .bind(approvalId, orgId)
    .first();

  if (!approval) {
    return Response.json({ error: "approbation introuvable" }, { status: 404 });
  }
  if (approval.status !== "pending") {
    return Response.json({ error: "déjà traitée" }, { status: 409 });
  }

  await env.DB.prepare(
    `UPDATE tool_approvals SET status = ?, decided_by = ?, decided_at = unixepoch() WHERE id = ?`,
  )
    .bind(body.decision, body.decidedBy, approvalId)
    .run();

  await env.DB.prepare(
    `INSERT INTO audit_log (id, org_id, actor_id, action, target, metadata_json)
     VALUES (?, ?, ?, ?, ?, ?)`,
  )
    .bind(
      crypto.randomUUID(),
      orgId,
      body.decidedBy,
      `approval.${body.decision}`,
      approval.tool_name as string,
      JSON.stringify({ approvalId }),
    )
    .run();

  // NB: relancer effectivement le run après approbation nécessite de
  // reprendre l'exécution depuis l'état sauvegardé (Durable Object /
  // Queue) -> prochaine brique à construire (reprise de run).
  return Response.json({ status: "ok", decision: body.decision });
}

import type { Env } from "./types";
import {
  handleCreateRun,
  handleGetRun,
  handleApprovalDecision,
} from "./api/routes";

export { AgentSession } from "./runtime/agent-session";

/**
 * Résout l'org_id à partir de la clé API envoyée en header.
 * Ne fait jamais confiance à un org_id fourni par le client dans l'URL
 * ou le body -> toujours dérivé de la clé authentifiée.
 */
async function resolveOrgFromApiKey(
  request: Request,
  env: Env,
): Promise<string | null> {
  const authHeader = request.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) return null;

  const rawKey = authHeader.slice("Bearer ".length).trim();
  if (!rawKey) return null;

  const keyHash = await sha256(rawKey);
  const row = await env.DB.prepare(
    `SELECT org_id FROM api_keys WHERE key_hash = ? AND revoked = 0`,
  )
    .bind(keyHash)
    .first();

  return (row?.org_id as string) ?? null;
}

async function sha256(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(hashBuffer)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const parts = url.pathname.split("/").filter(Boolean); // ["api","v1",...]

    if (parts[0] !== "api" || parts[1] !== "v1") {
      return Response.json({ error: "not found" }, { status: 404 });
    }

    const orgId = await resolveOrgFromApiKey(request, env);
    if (!orgId) {
      return Response.json({ error: "unauthorized" }, { status: 401 });
    }

    try {
      // POST /api/v1/agents/:agentId/runs
      if (
        parts[2] === "agents" &&
        parts[4] === "runs" &&
        request.method === "POST"
      ) {
        return await handleCreateRun(request, env, orgId, parts[3]);
      }

      // GET /api/v1/runs/:runId
      if (parts[2] === "runs" && parts[3] && request.method === "GET") {
        return await handleGetRun(env, orgId, parts[3]);
      }

      // POST /api/v1/approvals/:approvalId/decision
      if (
        parts[2] === "approvals" &&
        parts[4] === "decision" &&
        request.method === "POST"
      ) {
        return await handleApprovalDecision(request, env, orgId, parts[3]);
      }

      return Response.json({ error: "route inconnue" }, { status: 404 });
    } catch (err) {
      console.error(err);
      return Response.json({ error: "erreur interne" }, { status: 500 });
    }
  },
};

/**
 * AgentSession (Durable Object)
 *
 * Un DO par run actif. Garantit :
 *  - un seul run à la fois par session (pas de double-exécution concurrente
 *    du même agent sur le même contexte -> évite les effets de bord dupliqués)
 *  - la mémoire "short_term" reste en mémoire vive pendant tout le run,
 *    sans aller-retour D1 à chaque étape
 *  - un point de reprise après approbation humaine (waiting_approval -> resume)
 */
export class AgentSession {
  state: DurableObjectState;
  shortTermMemory: Array<{ role: string; content: string }> = [];
  locked = false;

  constructor(state: DurableObjectState) {
    this.state = state;
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname.endsWith("/lock")) {
      if (this.locked) {
        return Response.json({ error: "session déjà verrouillée" }, { status: 409 });
      }
      this.locked = true;
      await this.state.storage.put("locked", true);
      return Response.json({ ok: true });
    }

    if (url.pathname.endsWith("/unlock")) {
      this.locked = false;
      await this.state.storage.put("locked", false);
      return Response.json({ ok: true });
    }

    if (url.pathname.endsWith("/memory") && request.method === "GET") {
      const stored =
        (await this.state.storage.get<typeof this.shortTermMemory>(
          "memory",
        )) ?? [];
      return Response.json({ memory: stored });
    }

    if (url.pathname.endsWith("/memory") && request.method === "POST") {
      const body = await request.json<{ role: string; content: string }>();
      this.shortTermMemory.push(body);
      await this.state.storage.put("memory", this.shortTermMemory);
      return Response.json({ ok: true });
    }

    return new Response("not found", { status: 404 });
  }
}

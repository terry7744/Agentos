import type { AgentConfig, Env, RunStepEvent } from "../types";
import { ToolEngine } from "../tools/tool-engine";

interface ModelToolCall {
  toolName: string;
  input: unknown;
}

interface ModelDecision {
  type: "tool_call" | "final_answer";
  reasoning: string;
  toolCall?: ModelToolCall;
  finalAnswer?: string;
}

export interface RuntimeResult {
  status: "completed" | "waiting_approval" | "failed" | "stopped";
  output?: string;
  error?: string;
  stepsUsed: number;
  toolCallsUsed: number;
  tokensUsed: number;
}

/**
 * Boucle centrale de l'agent.
 *
 * Garde-fous anti-boucle-infinie (non négociables, jamais désactivables
 * depuis le prompt de l'agent) :
 *  - maxSteps          : nombre max d'itérations de raisonnement
 *  - maxToolCalls       : nombre max d'appels d'outils
 *  - maxTokensBudget    : budget total de tokens consommés
 *  - timeoutMs          : temps mur total pour tout le run
 */
export class AgentRuntime {
  constructor(
    private env: Env,
    private toolEngine: ToolEngine,
    private onStep: (event: RunStepEvent) => Promise<void>,
  ) {}

  async run(
    agent: AgentConfig,
    runId: string,
    userInput: string,
  ): Promise<RuntimeResult> {
    const startedAt = Date.now();
    let stepsUsed = 0;
    let toolCallsUsed = 0;
    let tokensUsed = 0;

    const conversation: Array<{ role: string; content: string }> = [
      { role: "system", content: agent.systemInstructions },
      { role: "user", content: userInput },
    ];

    while (stepsUsed < agent.maxSteps) {
      if (Date.now() - startedAt > agent.timeoutMs) {
        return this.stopped("timeout", stepsUsed, toolCallsUsed, tokensUsed);
      }
      if (tokensUsed > agent.maxTokensBudget) {
        return this.stopped(
          "token_budget_exceeded",
          stepsUsed,
          toolCallsUsed,
          tokensUsed,
        );
      }

      stepsUsed++;

      const { decision, tokens } = await this.decideNextStep(
        agent,
        conversation,
      );
      tokensUsed += tokens;

      await this.onStep({ type: "reasoning", content: decision.reasoning });

      if (decision.type === "final_answer") {
        await this.onStep({
          type: "final_answer",
          content: decision.finalAnswer ?? "",
        });
        return {
          status: "completed",
          output: decision.finalAnswer,
          stepsUsed,
          toolCallsUsed,
          tokensUsed,
        };
      }

      // decision.type === "tool_call"
      if (toolCallsUsed >= agent.maxToolCalls) {
        return this.stopped(
          "tool_call_budget_exceeded",
          stepsUsed,
          toolCallsUsed,
          tokensUsed,
        );
      }

      const call = decision.toolCall!;
      const tool = this.toolEngine.get(call.toolName);

      if (!tool) {
        conversation.push({
          role: "tool",
          content: `Erreur: tool "${call.toolName}" introuvable.`,
        });
        continue;
      }

      // Guardrail non contournable : au-dessus du seuil de risque configuré,
      // l'exécution s'arrête et attend une décision humaine explicite.
      if (this.toolEngine.requiresApproval(tool, agent)) {
        await this.onStep({
          type: "approval_requested",
          content: `Approbation requise pour "${call.toolName}"`,
          toolName: call.toolName,
          riskLevel: tool.riskLevel,
        });
        await this.env.DB.prepare(
          `INSERT INTO tool_approvals (id, run_id, org_id, tool_name, risk_level, input_json)
           VALUES (?, ?, ?, ?, ?, ?)`,
        )
          .bind(
            crypto.randomUUID(),
            runId,
            agent.orgId,
            call.toolName,
            tool.riskLevel,
            JSON.stringify(call.input),
          )
          .run();

        return {
          status: "waiting_approval",
          stepsUsed,
          toolCallsUsed,
          tokensUsed,
        };
      }

      toolCallsUsed++;
      await this.onStep({
        type: "tool_call",
        content: JSON.stringify(call.input),
        toolName: call.toolName,
        riskLevel: tool.riskLevel,
      });

      const result = await this.toolEngine.execute(
        call.toolName,
        call.input,
        agent,
        { env: this.env, orgId: agent.orgId, agentId: agent.id, runId },
        this.env,
      );

      await this.onStep({
        type: "tool_result",
        content: JSON.stringify(result),
        toolName: call.toolName,
      });

      conversation.push({
        role: "tool",
        content: JSON.stringify(result),
      });
    }

    return this.stopped("max_steps_reached", stepsUsed, toolCallsUsed, tokensUsed);
  }

  private stopped(
    reason: string,
    stepsUsed: number,
    toolCallsUsed: number,
    tokensUsed: number,
  ): RuntimeResult {
    return {
      status: "stopped",
      error: reason,
      stepsUsed,
      toolCallsUsed,
      tokensUsed,
    };
  }

  /**
   * Appelle le modèle pour décider de la prochaine étape.
   * Le modèle doit répondre en JSON strict — jamais de parsing "au mieux".
   */
  private async decideNextStep(
    agent: AgentConfig,
    conversation: Array<{ role: string; content: string }>,
  ): Promise<{ decision: ModelDecision; tokens: number }> {
    const tools = this.toolEngine
      .list()
      .filter((t) => agent.allowedTools.includes(t.name));

    const toolsDescription = tools
      .map((t) => `- ${t.name} (risque: ${t.riskLevel}): ${t.description}`)
      .join("\n");

    const systemPrompt = `Tu dois répondre UNIQUEMENT en JSON valide, de la forme :
{"type":"tool_call","reasoning":"...","toolCall":{"toolName":"...","input":{...}}}
ou
{"type":"final_answer","reasoning":"...","finalAnswer":"..."}

Outils disponibles:
${toolsDescription || "(aucun)"}`;

    const response = await this.env.AI.run(agent.model as any, {
      messages: [
        { role: "system", content: systemPrompt },
        ...conversation,
      ],
    });

    const text = (response as any).response ?? "{}";
    const tokens = (response as any).usage?.total_tokens ?? 0;

    try {
      const decision = JSON.parse(text) as ModelDecision;
      return { decision, tokens };
    } catch {
      // Le modèle n'a pas respecté le format JSON : on force une réponse
      // finale plutôt que de laisser l'agent boucler sur du texte libre.
      return {
        decision: {
          type: "final_answer",
          reasoning: "Format de réponse invalide du modèle",
          finalAnswer:
            "Une erreur interne est survenue pendant le raisonnement.",
        },
        tokens,
      };
    }
  }
}

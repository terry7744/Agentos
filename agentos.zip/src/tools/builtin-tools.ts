import { z } from "zod";
import type { ToolDefinition } from "../types";

/** LOW risk — lecture seule, pas d'effet de bord */
export const knowledgeSearchTool: ToolDefinition = {
  name: "knowledge_search",
  description: "Recherche dans la base de connaissances vectorielle de l'org",
  riskLevel: "LOW",
  inputSchema: z.object({
    query: z.string().min(1).max(1000),
    topK: z.number().min(1).max(20).default(5),
  }),
  timeoutMs: 8000,
  retryPolicy: { maxRetries: 2, backoffMs: 300 },
  execute: async (input, ctx) => {
    const embedding = await ctx.env.AI.run("@cf/baai/bge-base-en-v1.5", {
      text: [input.query],
    });
    const vector = (embedding as any).data[0];
    const results = await ctx.env.VECTORIZE.query(vector, {
      topK: input.topK,
      filter: { orgId: ctx.orgId },
    });
    return results.matches.map((m) => ({
      score: m.score,
      metadata: m.metadata,
    }));
  },
};

/** MEDIUM risk — écriture non destructive, réversible */
export const createTicketTool: ToolDefinition = {
  name: "create_ticket",
  description: "Crée un ticket de support",
  riskLevel: "MEDIUM",
  inputSchema: z.object({
    title: z.string().min(1).max(200),
    description: z.string().max(5000),
    priority: z.enum(["low", "normal", "high"]).default("normal"),
  }),
  timeoutMs: 10000,
  retryPolicy: { maxRetries: 1, backoffMs: 500 },
  execute: async (input, ctx) => {
    const id = crypto.randomUUID();
    // Intégration réelle (Zendesk/Linear/Notion...) à brancher ici.
    return { ticketId: id, status: "created", title: input.title };
  },
};

/** HIGH risk — impact externe direct, nécessite approbation par défaut */
export const sendEmailTool: ToolDefinition = {
  name: "send_email",
  description: "Envoie un email au nom de l'organisation",
  riskLevel: "HIGH",
  inputSchema: z.object({
    to: z.string().email(),
    subject: z.string().min(1).max(200),
    body: z.string().min(1).max(20000),
  }),
  timeoutMs: 10000,
  retryPolicy: { maxRetries: 1, backoffMs: 500 },
  execute: async (input, ctx) => {
    // Intégration réelle (Resend/Postmark/SES...) à brancher ici.
    return { status: "sent", to: input.to };
  },
};

/** CRITICAL risk — destructif/irréversible, TOUJOURS approbation obligatoire */
export const deleteDataTool: ToolDefinition = {
  name: "delete_data",
  description: "Supprime définitivement des données de l'org",
  riskLevel: "CRITICAL",
  inputSchema: z.object({
    resourceType: z.string(),
    resourceId: z.string(),
    confirm: z.literal(true),
  }),
  timeoutMs: 15000,
  retryPolicy: { maxRetries: 0, backoffMs: 0 },
  execute: async (input, ctx) => {
    return { status: "deleted", resourceId: input.resourceId };
  },
};

export const builtinTools = [
  knowledgeSearchTool,
  createTicketTool,
  sendEmailTool,
  deleteDataTool,
];

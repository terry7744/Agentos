import type {
  AgentConfig,
  Env,
  RiskLevel,
  ToolDefinition,
  ToolExecutionContext,
} from "../types";

const RISK_ORDER: Record<RiskLevel, number> = {
  LOW: 0,
  MEDIUM: 1,
  HIGH: 2,
  CRITICAL: 3,
};

export class ToolEngine {
  private registry = new Map<string, ToolDefinition>();

  register(tool: ToolDefinition) {
    if (this.registry.has(tool.name)) {
      throw new Error(`Tool "${tool.name}" déjà enregistré`);
    }
    this.registry.set(tool.name, tool);
  }

  get(name: string): ToolDefinition | undefined {
    return this.registry.get(name);
  }

  list(): ToolDefinition[] {
    return [...this.registry.values()];
  }

  /**
   * Détermine si l'appel nécessite une approbation humaine
   * avant exécution, selon la config de l'agent.
   */
  requiresApproval(tool: ToolDefinition, agent: AgentConfig): boolean {
    const threshold = agent.guardrails.requireApprovalAbove ?? "HIGH";
    return RISK_ORDER[tool.riskLevel] >= RISK_ORDER[threshold];
  }

  /**
   * Exécute un tool avec :
   * - vérification stricte que le tool est autorisé pour cet agent
   * - validation du schéma d'input (zod) -> jamais d'input non validé
   * - timeout dur
   * - retry avec backoff, seulement sur erreurs transitoires
   */
  async execute(
    toolName: string,
    rawInput: unknown,
    agent: AgentConfig,
    ctx: ToolExecutionContext,
    env: Env,
  ): Promise<{ ok: true; output: unknown } | { ok: false; error: string }> {
    const tool = this.registry.get(toolName);

    if (!tool) {
      return { ok: false, error: `Tool inconnu: ${toolName}` };
    }

    // Isolation stricte : un agent ne peut appeler QUE les tools qui lui
    // sont explicitement attribués. Pas d'exception, pas de fallback.
    if (!agent.allowedTools.includes(toolName)) {
      await this.logAudit(env, agent.orgId, "tool.denied", toolName, {
        reason: "not_in_allowed_tools",
        agentId: agent.id,
      });
      return {
        ok: false,
        error: `Tool "${toolName}" non autorisé pour cet agent`,
      };
    }

    const parsed = tool.inputSchema.safeParse(rawInput);
    if (!parsed.success) {
      return {
        ok: false,
        error: `Input invalide pour "${toolName}": ${parsed.error.message}`,
      };
    }

    let lastError = "";
    for (let attempt = 0; attempt <= tool.retryPolicy.maxRetries; attempt++) {
      try {
        const result = await this.withTimeout(
          tool.execute(parsed.data, ctx),
          tool.timeoutMs,
        );
        await this.logAudit(env, agent.orgId, "tool.executed", toolName, {
          agentId: agent.id,
          runId: ctx.runId,
          riskLevel: tool.riskLevel,
        });
        return { ok: true, output: result };
      } catch (err) {
        lastError = err instanceof Error ? err.message : String(err);
        if (attempt < tool.retryPolicy.maxRetries) {
          await sleep(tool.retryPolicy.backoffMs * (attempt + 1));
        }
      }
    }

    await this.logAudit(env, agent.orgId, "tool.failed", toolName, {
      agentId: agent.id,
      runId: ctx.runId,
      error: lastError,
    });
    return { ok: false, error: `Échec après retries: ${lastError}` };
  }

  private withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
    return Promise.race([
      promise,
      new Promise<T>((_, reject) =>
        setTimeout(() => reject(new Error(`Timeout après ${ms}ms`)), ms),
      ),
    ]);
  }

  private async logAudit(
    env: Env,
    orgId: string,
    action: string,
    target: string,
    metadata: Record<string, unknown>,
  ) {
    try {
      await env.DB.prepare(
        `INSERT INTO audit_log (id, org_id, actor_id, action, target, metadata_json)
         VALUES (?, ?, ?, ?, ?, ?)`,
      )
        .bind(
          crypto.randomUUID(),
          orgId,
          "system",
          action,
          target,
          JSON.stringify(metadata),
        )
        .run();
    } catch {
      // L'audit ne doit jamais faire planter l'exécution du tool.
    }
  }
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Génère une clé API AgentOS + son hash SHA-256.
 *
 * Usage :
 *   node --experimental-strip-types scripts/generate-api-key.ts
 *   (ou : npx tsx scripts/generate-api-key.ts)
 *
 * La clé en clair ne doit être montrée qu'une seule fois à l'utilisateur
 * (au moment de la création) puis jamais reloguée ni stockée ailleurs
 * que dans son propre gestionnaire de secrets. Seul le hash va en base.
 */
import { randomBytes, createHash } from "node:crypto";

function generateApiKey(): { rawKey: string; hash: string } {
  const rawKey = "agos_live_" + randomBytes(24).toString("hex");
  const hash = createHash("sha256").update(rawKey).digest("hex");
  return { rawKey, hash };
}

const { rawKey, hash } = generateApiKey();

console.log("Clé API (à copier maintenant, ne sera plus jamais affichée) :");
console.log(rawKey);
console.log();
console.log("Hash SHA-256 (à coller dans seed.sql / table api_keys.key_hash) :");
console.log(hash);

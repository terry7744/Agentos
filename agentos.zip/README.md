# AgentOS — socle Agent Runtime + Tool Engine

Ceci est le **cœur fonctionnel** d'AgentOS : un moteur d'agents IA sur
Cloudflare Workers, avec permissions strictes par niveau de risque et
approbation humaine obligatoire pour les actions sensibles.

## Ce qui est déjà fonctionnel

- **Agent Runtime** (`src/runtime/agent-runtime.ts`) : boucle
  raisonnement → décision → tool call → observation, avec budgets durs
  (steps, tool calls, tokens, timeout) qui ne peuvent PAS être contournés
  depuis le prompt de l'agent.
- **Tool Engine** (`src/tools/tool-engine.ts`) : exécution de tools avec
  validation stricte des inputs (zod), timeout, retry, et surtout :
  vérification que l'agent a explicitement le droit d'utiliser ce tool.
- **4 niveaux de risque** (LOW/MEDIUM/HIGH/CRITICAL) — au-dessus du seuil
  configuré, l'exécution s'arrête et crée une demande d'approbation en
  base plutôt que d'agir.
- **Isolation multi-tenant** : chaque requête D1/Vectorize est filtrée
  par `org_id`, dérivé uniquement de la clé API authentifiée (jamais
  d'un paramètre client).
- **Audit log** : chaque exécution de tool, refus, et décision
  d'approbation est journalisée.
- **API REST** : création de run, lecture de run + steps, décision
  d'approbation.

## Ce qu'il reste à construire (dans l'ordre recommandé)

1. **Reprise de run après approbation** — actuellement un run
   `waiting_approval` s'arrête ; il faut le relancer depuis l'état
   sauvegardé une fois approuvé (via le Durable Object `AgentSession`
   déjà posé, ou la Queue `RUN_QUEUE`).
2. **Ingestion de connaissances (RAG)** — pipeline upload → chunking →
   embeddings → Vectorize, pour remplir `knowledge_documents`.
3. **Auth complète** — création/rotation/scopes des `api_keys`,
   RBAC par rôle utilisateur.
4. **Dashboard frontend** (Next.js/React/Tailwind) branché sur cette API.
5. **Multi-agent & workflow engine** — une fois le runtime mono-agent
   solide et testé en usage réel.

## Démarrage

```bash
npm install
# Créer les ressources Cloudflare et remplacer les IDs dans wrangler.toml
npx wrangler d1 create agentos_db
npx wrangler vectorize create agentos_knowledge --dimensions=768 --metric=cosine
npx wrangler r2 bucket create agentos-files
npx wrangler queues create agentos-runs

npm run db:migrate
npm run dev
```

## Pourquoi cette architecture est "rentable" en priorité

Ce socle est volontairement le point qui débloque le plus de valeur par
euro de temps investi : sans runtime + permissions solides, rien
d'autre (dashboard, marketplace, billing) n'a de produit à vendre
derrière. Une fois ce socle stable, chaque couche ajoutée dessus
(RAG, multi-agent, workflows) est un module indépendant qui ne remet
pas en cause les fondations.
